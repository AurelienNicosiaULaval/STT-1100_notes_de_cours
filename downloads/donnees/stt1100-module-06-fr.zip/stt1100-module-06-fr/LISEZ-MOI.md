# STT-1100 - Module 06

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_06/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `data/organisations_donnees_quebec.csv` | Table des 142 organisations présentes dans l'extrait relationnel. | [Source](https://www.donneesquebec.ca/recherche/api/3/action/package_search) - CC BY 4.0 |
| `data/jeux_donnees_quebec.csv` | Table de 312 jeux de données québécois. | [Source](https://www.donneesquebec.ca/recherche/api/3/action/package_search) - CC BY 4.0 |
| `data/ressources_donnees_quebec.csv` | Table de 3 143 ressources liées aux jeux de données. | [Source](https://www.donneesquebec.ca/recherche/api/3/action/package_search) - CC BY 4.0 |
| `data/etiquettes_donnees_quebec.csv` | Table de 2 101 associations entre jeux et étiquettes. | [Source](https://www.donneesquebec.ca/recherche/api/3/action/package_search) - CC BY 4.0 |
