# STT-1100 - Module 08

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_08/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `data/catalogue_donnees_quebec.html` | HTML snapshot of six real records from six cities. | [Source](https://www.donneesquebec.ca/page-api/) - CC BY 4.0 |
| `data/catalogue_donnees_quebec_irregulier.html` | HTML snapshot of four records, including two without a category. | [Source](https://www.donneesquebec.ca/page-api/) - CC BY 4.0 |
| `data/evenements_sit_quebec.html` | HTML snapshot of six events announced in six cities. | [Source](https://www.donneesquebec.ca/recherche/dataset/sit-quebec-evenements) - CC BY 4.0 |
