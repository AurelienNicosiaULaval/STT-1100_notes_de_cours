# STT-1100 - Module 09

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_09/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `data/consommation_eau_municipalites_2023.csv` | Consommation résidentielle et eau distribuée dans 496 municipalités. | [Source](https://www.donneesquebec.ca/recherche/dataset/sqeep-2019-2025) - CC BY 4.0 |
| `data/validite_audits_eau_2023.csv` | Disponibilité et résultats de l'indice de validité pour 1 104 municipalités. | [Source](https://www.donneesquebec.ca/recherche/dataset/sqeep-2019-2025) - CC BY 4.0 |
