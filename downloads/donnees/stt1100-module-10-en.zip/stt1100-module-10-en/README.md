# STT-1100 - Module 10

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_10/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `data/quebec_dataset_descriptions.csv` | Real descriptions of 89 datasets published by eight Quebec cities. | [Source](https://www.donneesquebec.ca/page-api/) - CC BY 4.0 |
| `data/quebec_tourism_events.csv` | Balanced sample of 151 tourism events. | [Source](https://www.donneesquebec.ca/recherche/dataset/sit-quebec-evenements) - CC BY 4.0 |
