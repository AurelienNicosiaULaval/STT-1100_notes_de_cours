# STT-1100 - Module 09

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_09/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `data/municipal_water_consumption_2023.csv` | Residential consumption and distributed water in 496 municipalities. | [Source](https://www.donneesquebec.ca/recherche/dataset/sqeep-2019-2025) - CC BY 4.0 |
| `data/water_audit_validity_2023.csv` | Availability and validity-index results for 1,104 municipalities. | [Source](https://www.donneesquebec.ca/recherche/dataset/sqeep-2019-2025) - CC BY 4.0 |
