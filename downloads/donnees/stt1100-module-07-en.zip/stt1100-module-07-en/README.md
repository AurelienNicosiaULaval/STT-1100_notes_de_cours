# STT-1100 - Module 07

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_07/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `data/incidents_securite_sherbrooke_agreges.csv` | Incidents aggregated by month and type, without coordinates or exact dates. | [Source](https://www.donneesquebec.ca/recherche/dataset/64d19d62f0804f5896e4b24c32aea49d_0) - CC BY 4.0 |
| `data/population_sherbrooke_2022_2024.csv` | Annual population estimates used to calculate rates. | [Source](https://www150.statcan.gc.ca/t1/tbl1/fr/tv.action?pid=1710015501) - Licence ouverte du gouvernement du Canada |
| `data/sondage_utilisateurs_donnees_quebec_2020_2025.csv` | Aggregated responses to three public consultation questions. | [Source](https://www.donneesquebec.ca/recherche/dataset/sondage) - CC BY 4.0 |
