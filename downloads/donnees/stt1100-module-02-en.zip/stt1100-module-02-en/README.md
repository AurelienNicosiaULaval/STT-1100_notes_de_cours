# STT-1100 - Module 02

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_02/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `resources/manchots_donnees.xlsx` | Excel workbook prepared for learning data import and visualization. | [Source](https://allisonhorst.github.io/palmerpenguins/) - Matériel pédagogique du cours |
| `data/arbres_repertories_quebec.csv` | A 500-tree extract from Quebec City's public inventory. | [Source](https://www.donneesquebec.ca/recherche/dataset/34103a43-3712-4a29-92e1-039e9188e915) - CC BY 4.0 |
| `data/comptages_cyclistes_quebec_2026.csv` | Snapshot of totals published by eleven cycling count sites. | [Source](https://villedequebec.eco-counter.com/) - Conditions de la source |
