# STT-1100 - Module 05

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_05/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `data/comptages_velos_laval_2016_06.csv` | Fifteen-minute counts at the Chevillon loop in June 2016. | [Source](https://www.donneesquebec.ca/recherche/dataset/comptages-velos) - CC BY 4.0 |
| `data/qualite_air_quebec_vieux_limoilou_2025_07.csv` | Hourly measurements at the Quebec City Vieux-Limoilou station. | [Source](https://www.donneesquebec.ca/recherche/dataset/rsqaq-donnees-horaires-continues) - CC BY 4.0 |
| `data/debits_circulation_gatineau_2016_2023.csv` | Extract of road traffic measurements from 2016 to 2023. | [Source](https://www.donneesquebec.ca/recherche/dataset/debits-de-circulation) - CC BY 4.0 |
