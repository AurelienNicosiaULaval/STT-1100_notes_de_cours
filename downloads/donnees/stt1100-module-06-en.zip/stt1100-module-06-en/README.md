# STT-1100 - Module 06

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_06/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `data/organisations_donnees_quebec.csv` | Table of 142 organizations in the relational extract. | [Source](https://www.donneesquebec.ca/recherche/api/3/action/package_search) - CC BY 4.0 |
| `data/jeux_donnees_quebec.csv` | Table of 312 Quebec datasets. | [Source](https://www.donneesquebec.ca/recherche/api/3/action/package_search) - CC BY 4.0 |
| `data/ressources_donnees_quebec.csv` | Table of 3,143 resources linked to datasets. | [Source](https://www.donneesquebec.ca/recherche/api/3/action/package_search) - CC BY 4.0 |
| `data/etiquettes_donnees_quebec.csv` | Table of 2,101 links between datasets and tags. | [Source](https://www.donneesquebec.ca/recherche/api/3/action/package_search) - CC BY 4.0 |
