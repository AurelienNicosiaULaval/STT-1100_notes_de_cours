# STT-1100 - Module 01

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_01/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `data/bibliotheques_publiques_quebec_2024.csv` | Statistiques de 188 bibliothèques publiques et centres régionaux du Québec. | [Source](https://www.donneesquebec.ca/recherche/dataset/statistiques_des_bibliotheques_publiques_du_quebec) - CC BY 4.0 |
| `data/frequentation_portail_montreal_2023.csv` | Fréquentation de pages du portail de données ouvertes de Montréal pendant une journée. | [Source](https://donnees.montreal.ca/dataset/frequentation-du-portail-de-donnees-ouvertes) - CC BY 4.0 |
