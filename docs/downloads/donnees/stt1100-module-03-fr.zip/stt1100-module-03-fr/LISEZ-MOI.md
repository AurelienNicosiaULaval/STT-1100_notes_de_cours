# STT-1100 - Module 03

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_03/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `data/requetes_311_montreal.csv` | Extrait de 750 demandes de services citoyennes 311. | [Source](https://donnees.montreal.ca/dataset/requete-311) - CC BY 4.0 |
| `data/plaintes_consommation_quebec.csv` | Extrait de 750 plaintes reçues par l'Office de la protection du consommateur. | [Source](https://www.donneesquebec.ca/recherche/dataset/liste-des-plaintes-recues) - CC BY 4.0 |
