# STT-1100 - Module 03

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_03/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `data/requetes_311_montreal.csv` | A 750-row extract of 311 citizen service requests. | [Source](https://donnees.montreal.ca/dataset/requete-311) - CC BY 4.0 |
| `data/plaintes_consommation_quebec.csv` | A 750-row extract of complaints received by Quebec's consumer protection office. | [Source](https://www.donneesquebec.ca/recherche/dataset/liste-des-plaintes-recues) - CC BY 4.0 |
