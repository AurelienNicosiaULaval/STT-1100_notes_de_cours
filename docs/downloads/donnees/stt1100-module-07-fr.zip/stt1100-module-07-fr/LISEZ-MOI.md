# STT-1100 - Module 07

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_07/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `data/incidents_securite_sherbrooke_agreges.csv` | Incidents agrégés par mois et par type, sans coordonnées ni dates exactes. | [Source](https://www.donneesquebec.ca/recherche/dataset/64d19d62f0804f5896e4b24c32aea49d_0) - CC BY 4.0 |
| `data/population_sherbrooke_2022_2024.csv` | Estimations annuelles de population utilisées pour calculer des taux. | [Source](https://www150.statcan.gc.ca/t1/tbl1/fr/tv.action?pid=1710015501) - Licence ouverte du gouvernement du Canada |
| `data/sondage_utilisateurs_donnees_quebec_2020_2025.csv` | Réponses agrégées à trois questions de la consultation publique. | [Source](https://www.donneesquebec.ca/recherche/dataset/sondage) - CC BY 4.0 |
