# STT-1100 - Module 04

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_04/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `policies.csv` | Petit fichier de polices utilisé pour diagnostiquer les types et les valeurs. | Matériel pédagogique du cours |
| `coverage.json` | Petit fichier JSON utilisé pour apprendre les données imbriquées. | Matériel pédagogique du cours |
| `resources/quotes_2024.xlsx` | Feuille Excel contenant cinq soumissions de pratique. | Matériel pédagogique du cours |
| `data/afdr_clientele_prestations_2022_12.csv` | Tableau agrégé de la clientèle et des prestations au Québec. | [Source](https://www.donneesquebec.ca/recherche/dataset/aide-financiere-de-dernier-recours-afdr-clientele-et-prestations) - CC BY 4.0 |
| `data/installations_sportives_sherbrooke.csv` | Inventaire de 859 installations sportives et récréatives. | [Source](https://www.donneesquebec.ca/recherche/dataset/b6498f3436974ecbb8fa636a7d9c0b2f_0) - CC BY 4.0 |
| `data/metadonnees_installations_sherbrooke.json` | Métadonnées ArcGIS associées à l'inventaire des installations. | [Source](https://www.donneesquebec.ca/recherche/dataset/b6498f3436974ecbb8fa636a7d9c0b2f_0) - CC BY 4.0 |
