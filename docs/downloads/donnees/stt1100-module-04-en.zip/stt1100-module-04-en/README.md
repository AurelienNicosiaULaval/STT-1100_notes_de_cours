# STT-1100 - Module 04

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_04/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `policies.csv` | Small policy file used to diagnose types and values. | Matériel pédagogique du cours |
| `coverage.json` | Small JSON file used to learn nested data. | Matériel pédagogique du cours |
| `resources/quotes_2024.xlsx` | Excel workbook containing five practice quotes. | Matériel pédagogique du cours |
| `data/afdr_clientele_prestations_2022_12.csv` | Aggregated table of clients and benefits in Quebec. | [Source](https://www.donneesquebec.ca/recherche/dataset/aide-financiere-de-dernier-recours-afdr-clientele-et-prestations) - CC BY 4.0 |
| `data/installations_sportives_sherbrooke.csv` | Inventory of 859 sports and recreational facilities. | [Source](https://www.donneesquebec.ca/recherche/dataset/b6498f3436974ecbb8fa636a7d9c0b2f_0) - CC BY 4.0 |
| `data/metadonnees_installations_sherbrooke.json` | ArcGIS metadata associated with the facility inventory. | [Source](https://www.donneesquebec.ca/recherche/dataset/b6498f3436974ecbb8fa636a7d9c0b2f_0) - CC BY 4.0 |
