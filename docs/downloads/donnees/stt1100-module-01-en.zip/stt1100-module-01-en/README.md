# STT-1100 - Module 01

This folder contains every file required for the module's consolidation exercises.

## Getting started

1. Open the `.Rproj` file in this folder.
2. Open `module_workspace.qmd`.
3. Read the [exercise instructions](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/en/module_01/exercices.html).
4. Keep the supplied files in their current folders so that relative paths continue to work.

Solutions are not included in this workspace.

## Supplied files

| File | Description | Source and licence |
|---|---|---|
| `data/bibliotheques_publiques_quebec_2024.csv` | Statistics for 188 Quebec public libraries and regional centres. | [Source](https://www.donneesquebec.ca/recherche/dataset/statistiques_des_bibliotheques_publiques_du_quebec) - CC BY 4.0 |
| `data/frequentation_portail_montreal_2023.csv` | Page traffic on Montreal's Open Data Portal during one day. | [Source](https://donnees.montreal.ca/dataset/frequentation-du-portail-de-donnees-ouvertes) - CC BY 4.0 |
