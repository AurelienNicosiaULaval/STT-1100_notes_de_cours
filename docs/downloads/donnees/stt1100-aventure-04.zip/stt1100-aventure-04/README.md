# Aventure 4 - Nettoyer une base d'assurance

Bienvenue dans le dépôt de départ de l'aventure 4 du cours STT-1100.

Vous recevez une base de données d'assurance qui ressemble à un vrai fichier de travail: des séparateurs à vérifier, des valeurs douteuses, des formats incohérents et des décisions à documenter. Votre mandat est de produire une version propre du fichier, sans cacher les choix faits pendant le nettoyage.

Un bon nettoyage n'est pas seulement du code qui fonctionne. C'est aussi une trace claire de ce qui a été corrigé, supprimé, transformé ou laissé tel quel.

## Carte de mission

| Élément | Détail |
|---|---|
| Votre rôle | Ingénieur·e de données junior |
| Interlocuteur | Alex, responsable de l'équipe analytique |
| Organisation | Compagnie d'assurance fictive |
| Mission | Nettoyer une archive client et documenter les décisions de correction |
| Données | `dataset_pratique.csv` |
| Livrables | `donnees_propres.csv`, `journal_nettoyage.Rdata` et rapport Quarto |

Ici, votre meilleure preuve de compétence est la traçabilité: une autre personne doit comprendre ce que vous avez changé et pourquoi.

## Ce que vous allez pratiquer

- importer correctement un fichier CSV non standard;
- inspecter les types de variables;
- repérer des valeurs manquantes ou incohérentes;
- corriger des problèmes de format;
- sauvegarder un jeu de données propre;
- documenter les décisions de nettoyage dans un objet R.

## Contenu du dépôt

- `dataset_pratique.csv`: données brutes à nettoyer.
- `defi_04.qmd`: squelette Quarto à compléter.
- `aventure-4.Rproj`: projet RStudio à ouvrir pour utiliser les chemins relatifs.
- `README.md`: ce guide de départ.

## Point d'attention

Le fichier CSV est séparé par des points-virgules. Utilisez `readr::read_delim(delim = ";", locale = readr::locale(encoding = "UTF-8", decimal_mark = "."))`, comme dans le squelette. `read_csv2()` utilise par défaut une virgule décimale, ce qui ne correspond pas à ce fichier. Gardez le fichier brut intact.

Après l’importation, le tableau doit contenir 101 778 lignes et 23 colonnes. Si ce n'est pas le cas, l'importation n'a probablement pas été faite avec le bon séparateur.

## Démarrage rapide

1. Ouvrez `aventure-4.Rproj` dans RStudio, puis `defi_04.qmd`.
2. Rendez le document une première fois pour vérifier l'environnement.
3. Importez `dataset_pratique.csv` avec le bon séparateur.
4. Vérifiez le nombre de colonnes et les types de variables.
5. Commencez le journal de nettoyage dès la première décision importante.

## Fichiers à remettre

Votre dépôt final doit contenir:

- `defi_04.qmd` complété;
- `donnees_propres.csv`;
- `journal_nettoyage.Rdata`;
- `README.md`.

Le fichier Quarto doit pouvoir être rendu sans erreur.

## Checklist avant remise

- L'importation produit bien 23 colonnes.
- Les étapes de nettoyage sont reproductibles dans `defi_04.qmd`.
- `donnees_propres.csv` est créé par le code.
- `journal_nettoyage.Rdata` contient une liste R nommée `journal_nettoyage`.
- Les décisions importantes sont expliquées brièvement.
- Les changements sont poussés sur GitHub.

## Consignes et environnement

- [Aventure 4](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_04/aventure.html)
- [Défi 4 et grille d’évaluation](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_04/defi.html)
- Les modalités et la date de remise officielles figurent dans Brio.

Le squelette illustre une correction et se rend dès le départ, mais ce premier rendu ne satisfait pas encore le défi. Complétez au moins cinq vérifications, trois corrections distinctes et cinq entrées justifiées dans le journal. Le HTML permet de contrôler votre travail; les trois livrables demandés sont le `.qmd`, le `.csv` et le `.Rdata`.

Si nécessaire, installez une fois les packages dans la console R :

```r
install.packages(c("readr", "dplyr", "janitor", "ggplot2", "stringr", "forcats"))
```

Redémarrez R, puis rendez le document en entier avant la remise. Vérifiez aussi dans GitHub que les fichiers ont bien été poussés.

## Version du matériel

Version du 25 septembre 2026. Le fichier contient volontairement des anomalies pour soutenir la progression de nettoyage. Il doit comporter 101 778 lignes avant nettoyage. Une copie antérieure de 101 768 lignes ne correspond pas à cette version. Conservez cette nouvelle donnée d’entrée intacte, puis réalisez les transformations dans `base`.

Si votre dépôt personnel est indisponible, utilisez le [dossier de démarrage téléchargeable](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/downloads/donnees/stt1100-aventure-04.zip). Extrayez-le dans un nouveau dossier, ouvrez le projet RStudio et conservez vos fichiers localement jusqu’à l’attribution de l’accès GitHub.
