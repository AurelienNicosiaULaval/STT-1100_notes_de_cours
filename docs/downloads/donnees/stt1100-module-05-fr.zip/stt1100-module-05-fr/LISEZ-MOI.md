# STT-1100 - Module 05

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_05/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `data/comptages_velos_laval_2016_06.csv` | Comptages aux quinze minutes à la boucle Chevillon en juin 2016. | [Source](https://www.donneesquebec.ca/recherche/dataset/comptages-velos) - CC BY 4.0 |
| `data/qualite_air_quebec_vieux_limoilou_2025_07.csv` | Mesures horaires à la station Québec - Vieux-Limoilou. | [Source](https://www.donneesquebec.ca/recherche/dataset/rsqaq-donnees-horaires-continues) - CC BY 4.0 |
| `data/debits_circulation_gatineau_2016_2023.csv` | Extrait de mesures de circulation routière de 2016 à 2023. | [Source](https://www.donneesquebec.ca/recherche/dataset/debits-de-circulation) - CC BY 4.0 |
