# STT-1100 - Module 08

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_08/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `data/catalogue_donnees_quebec.html` | Instantané HTML de six fiches réelles provenant de six villes. | [Source](https://www.donneesquebec.ca/page-api/) - CC BY 4.0 |
| `data/catalogue_donnees_quebec_irregulier.html` | Instantané HTML de quatre fiches, dont deux sans catégorie. | [Source](https://www.donneesquebec.ca/page-api/) - CC BY 4.0 |
| `data/evenements_sit_quebec.html` | Instantané HTML de six événements annoncés dans six villes. | [Source](https://www.donneesquebec.ca/recherche/dataset/sit-quebec-evenements) - CC BY 4.0 |
