# STT-1100 - Module 02

Ce dossier contient tous les fichiers nécessaires aux exercices de consolidation du module.

## Démarrage

1. Ouvrez le fichier `.Rproj` de ce dossier.
2. Ouvrez `travail_module.qmd`.
3. Consultez les [consignes des exercices](https://aureliennicosiaulaval.github.io/STT-1100_notes_de_cours/module_02/exercices.html).
4. Conservez les fichiers dans leur dossier actuel afin que les chemins relatifs fonctionnent.

Les solutions ne sont pas incluses dans ce dossier de travail.

## Fichiers fournis

| Fichier | Description | Source et licence |
|---|---|---|
| `resources/manchots_donnees.xlsx` | Feuille Excel préparée pour apprendre l'importation et la visualisation. | [Source](https://allisonhorst.github.io/palmerpenguins/) - Matériel pédagogique du cours |
| `data/arbres_repertories_quebec.csv` | Extrait de 500 arbres de l'inventaire public de la Ville de Québec. | [Source](https://www.donneesquebec.ca/recherche/dataset/34103a43-3712-4a29-92e1-039e9188e915) - CC BY 4.0 |
| `data/comptages_cyclistes_quebec_2026.csv` | Instantané des totaux publiés par onze sites de comptage cycliste. | [Source](https://villedequebec.eco-counter.com/) - Conditions de la source |
